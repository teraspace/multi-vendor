SpreeStorefrontConfig = YAML.load_file(Rails.root.join('config', 'spree_storefront.yml')).with_indifferent_access
