# This migration comes from spree (originally 20141023005240)
class AddCounterCacheFromSpreeVariantsToSpreeStockItems < ActiveRecord::Migration[4.2]
  # This was unnecessary and was removed
  def up
  end

  def down
  end
end
